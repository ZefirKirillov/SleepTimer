package com.kirill.sleepalarm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.IBinder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class WatcherService : Service() {

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            if (intent.action != Intent.ACTION_SCREEN_OFF) return
            val wake = Scheduler.computeWake(ctx) ?: return
            Scheduler.set(ctx, wake)
            val t = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(wake))
            notify(ctx, "Будильник на $t")
        }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("watcher", "Слежение", NotificationManager.IMPORTANCE_MIN)
        )
        startForeground(1, buildNotification(this, "Жду, когда погаснет экран"))
        // ACTION_SCREEN_OFF нельзя объявить в манифесте — только динамически
        registerReceiver(receiver, IntentFilter(Intent.ACTION_SCREEN_OFF))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onDestroy() {
        unregisterReceiver(receiver)
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null

    companion object {
        fun buildNotification(c: Context, text: String): Notification =
            Notification.Builder(c, "watcher")
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("Циклы сна")
                .setContentText(text)
                .setOngoing(true)
                .build()

        fun notify(c: Context, text: String) {
            c.getSystemService(NotificationManager::class.java)
                .notify(1, buildNotification(c, text))
        }

        fun start(c: Context) =
            c.startForegroundService(Intent(c, WatcherService::class.java))

        fun stop(c: Context) = c.stopService(Intent(c, WatcherService::class.java))
    }
}

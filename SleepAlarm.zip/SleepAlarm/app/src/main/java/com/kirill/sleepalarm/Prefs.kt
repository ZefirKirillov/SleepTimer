package com.kirill.sleepalarm

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    fun enabled(c: Context) = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    fun targetHour(c: Context) = sp(c).getInt("hour", 8)
    fun targetMinute(c: Context) = sp(c).getInt("minute", 0)
    fun setTarget(c: Context, h: Int, m: Int) =
        sp(c).edit().putInt("hour", h).putInt("minute", m).apply()

    // Сколько минут человек засыпает после блокировки экрана
    fun fallAsleep(c: Context) = sp(c).getInt("fall_asleep", 15)
    fun setFallAsleep(c: Context, v: Int) = sp(c).edit().putInt("fall_asleep", v).apply()

    // На сколько минут можно проспать цель, если так выходит ближе к концу цикла
    fun tolerance(c: Context) = sp(c).getInt("tolerance", 10)
    fun setTolerance(c: Context, v: Int) = sp(c).edit().putInt("tolerance", v).apply()
}

package com.kirill.sleepalarm

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.TimePicker
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 0)
        }
        if (Build.VERSION.SDK_INT >= 31) {
            val am = getSystemService(AlarmManager::class.java)
            if (!am.canScheduleExactAlarms()) {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                        Uri.parse("package:$packageName"))
                )
            }
        }

        val picker = TimePicker(this).apply {
            setIs24HourView(true)
            hour = Prefs.targetHour(this@MainActivity)
            minute = Prefs.targetMinute(this@MainActivity)
            setOnTimeChangedListener { _, h, m ->
                Prefs.setTarget(this@MainActivity, h, m); refresh()
            }
        }

        val sw = Switch(this).apply {
            text = "Следить за экраном и ставить будильник"
            isChecked = Prefs.enabled(this@MainActivity)
            setOnCheckedChangeListener { _, on ->
                Prefs.setEnabled(this@MainActivity, on)
                if (on) WatcherService.start(this@MainActivity)
                else { WatcherService.stop(this@MainActivity); Scheduler.cancel(this@MainActivity) }
            }
        }

        info = TextView(this).apply { textSize = 18f; setPadding(0, 32, 0, 32) }

        val test = Button(this).apply {
            text = "Если лечь спать прямо сейчас"
            setOnClickListener { refresh() }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(48, 48, 48, 48)
            addView(TextView(this@MainActivity).apply { text = "Встать к:"; textSize = 20f })
            addView(picker)
            addView(sw)
            addView(info)
            addView(test)
        })

        if (Prefs.enabled(this)) WatcherService.start(this)
        refresh()
    }

    private fun refresh() {
        val wake = Scheduler.computeWake(this)
        info.text = if (wake == null) "Ни один цикл уже не помещается"
        else "Если заснуть сейчас, будильник прозвонит в " +
            SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(wake))
    }
}

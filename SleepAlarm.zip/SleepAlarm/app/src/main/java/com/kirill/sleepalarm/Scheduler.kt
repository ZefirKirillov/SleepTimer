package com.kirill.sleepalarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object Scheduler {
    const val CYCLE_MIN = 90

    /** Возвращает время будильника в мс или null, если ни один цикл не помещается. */
    fun computeWake(c: Context, nowMs: Long = System.currentTimeMillis()): Long? {
        val sleepStart = nowMs + Prefs.fallAsleep(c) * 60_000L

        val cal = Calendar.getInstance().apply {
            timeInMillis = nowMs
            set(Calendar.HOUR_OF_DAY, Prefs.targetHour(c))
            set(Calendar.MINUTE, Prefs.targetMinute(c))
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= nowMs) add(Calendar.DAY_OF_YEAR, 1)
        }
        val target = cal.timeInMillis

        val availableMin = (target - sleepStart) / 60_000L + Prefs.tolerance(c)
        val cycles = (availableMin / CYCLE_MIN).toInt()
        if (cycles < 1) return null
        // Ночь не длиннее 12 часов: иначе это дневной экран, а не отход ко сну
        if (target - nowMs > 12 * 60 * 60_000L) return null

        return sleepStart + cycles * CYCLE_MIN * 60_000L
    }

    private fun pending(c: Context): PendingIntent =
        PendingIntent.getBroadcast(
            c, 1, Intent(c, AlarmReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    fun set(c: Context, wakeMs: Long) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val show = PendingIntent.getActivity(
            c, 2, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        am.setAlarmClock(AlarmManager.AlarmClockInfo(wakeMs, show), pending(c))
    }

    fun cancel(c: Context) {
        (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending(c))
    }
}

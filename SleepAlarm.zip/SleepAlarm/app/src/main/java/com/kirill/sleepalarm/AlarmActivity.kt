package com.kirill.sleepalarm

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout

class AlarmActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val btn = Button(this).apply {
            text = "Выключить"
            textSize = 28f
            setOnClickListener {
                stopService(Intent(this@AlarmActivity, AlarmService::class.java))
                finish()
            }
        }
        setContentView(LinearLayout(this).apply {
            gravity = Gravity.CENTER
            addView(btn)
        })
    }
}
